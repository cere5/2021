using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bullet : MonoBehaviour
{
    public float speed = 8f; // 작성할 부분
    private Rigidbody bulletRigidbody; // 작성할 부분
    void Start()
    {
        // 현재 부착된 게임 오브젝트의 Rigidbody 컴포넌트를 찾아옴
        bulletRigidbody = GetComponent<Rigidbody>(); // 작성할 부분
        // 탄알의 속도 = 탄알 앞쪽 방향 * 속력(8f)
        bulletRigidbody.velocity = transform.forward * speed; // 작성할 부분

        // 탄알들이 영원히 직진하고 없어지지 않는다면 메모리 낭비가 심함
        Destroy(gameObject, 3f); // 작성할 부분
    }

    // 트리거 충돌이 감지될 경우 자동으로 실행되는 메서드
    void OnTriggerEnter(Collider other) // 작성할 OnTriggerEnter 메서드
    {
        if (other.tag == "Player") // 만약 충돌한 상대의 태그가 Player 라면
        {
            PlayerController playerController = other.GetComponent<PlayerController>(); // 상대방 PlayerController 컴포넌트를 가져와
            if (playerController != null)
            {
                playerController.Die(); // 그 안의 Die() 메서드 실행으로 플레이어 게임오버 처리
            }
        }
    }
}
