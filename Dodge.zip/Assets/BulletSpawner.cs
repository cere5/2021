using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BulletSpawner : MonoBehaviour
{
    // 생성할 탄알의 원본을 받아오는 변수
    public GameObject bulletPrefab;
    
    // 총알의 생성 주기는 0.5초 ~ 3초 사이 랜덤
    public float spawnRateMin = 0.5f;
    public float spawnRateMax = 3f;

    // 총알을 발사할 대상의 위치 (플레이어의 위치를 받아옴)
    private Transform target;

    // 랜덤 함수에 의해 확정된 다음 탄이 발사될때까지의 시간 (생성 주기)
    private float spawnRate;

    // 이전 총알을 생성하고 얼마나 시간이 흘렀는지
    private float timeAfterSpawn;

    void Start()
    {
        // 이전 총알생성 시간 초기화
        timeAfterSpawn = 0;
        // 다음 탄알이 몇초 후에 생성될지 랜덤으로 정함
        spawnRate = Random.Range(spawnRateMin, spawnRateMax);
        // 하이라키 전체를 검색해 PlayerController 컴포넌트가 붙어있는 오브젝트를 찾음(플레이어가 찾아짐) 이후 플레이어에게 탄알을 쏘기 위해 플레이어의 위치정보 transform 을 받아옴
        target = FindObjectOfType<PlayerController>().transform;
    }

    void Update()
    {
        // 매 프레임 흐른 시간을 갱신해줌
        timeAfterSpawn += Time.deltaTime;
        if(timeAfterSpawn > spawnRate) // 생성 주기보다 많은 시간이 흘렀다면
        {
            // 흐른 시간을 0으로 갱신
            timeAfterSpawn = 0;
            // 탄알을 생성
            GameObject bullet = Instantiate(bulletPrefab, transform.position, transform.rotation);
            // 탄알이 플레이어를 보게 설정
            bullet.transform.LookAt(target);
            // 다음 탄알이 몇초 후에 생성될지 랜덤으로 설정
            spawnRate = Random.Range(spawnRateMin, spawnRateMax);
        }
    }
}
