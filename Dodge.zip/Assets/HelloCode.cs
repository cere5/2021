using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HelloCode : MonoBehaviour
{
    void GetInfo(string charName, char bloodType, int age, float height, bool isMale)
    {
        Debug.Log("캐릭터 이름 : " + charName);
        Debug.Log("혈액형 : " + bloodType);
        Debug.Log("나이 : " + age);
        Debug.Log("키 : " + height);
        Debug.Log("남자인가요?: " + isMale);
    }

    void Start()
    {
        Debug.Log("Hello World!");

        // 주석(comment) 컴퓨터가 코드로서 처리하지 않는 영역, 주로 설명, 메모 용도로 사용

        /* 여러
        줄에 걸쳐서
        주석을 쓰려면 이렇게 */

        // 변수(variables) : 값을 저장하는 장소, 언제든 수정 가능
        // ; 세미콜론 : 컴퓨터에게 한 문장이 끝났다고 알려줌
        // = : 대입 연산자, gold 라는 이름의 메모리에 1000 이라는 값을 할당
        // 코드를 작성할때 = 은 같다는 뜻이 아니에요, 값이 언제든 변할 수 있습니다

        // string : 문자열
        string charName = "홍길동";

        // char : 문자 '하나'
        char bloodType = 'A';

        // integer(정수, 소수점이 없는 숫자) 타입을 명시하고 "선언" -> 새 변수를 만듬
        int age = 18;

        // float : 소수점이 있는 실수, 소수점 아래 7자리 까지만 정확해요
        float height = 173.5f;

        // boolean : 불리언, 불린 값으로 참/거짓 둘 중 하나를 저장해요
        bool isMale = true;

        // 생성한 변수를 콘솔로 출력
        Debug.Log("캐릭터 이름 : " + charName);
        Debug.Log("혈액형 : " + bloodType);
        Debug.Log("나이 : " + age);
        Debug.Log("키 : " + height);
        Debug.Log("남자인가요?: " + isMale);

        GetInfo(charName, bloodType, age, height, isMale);
    }
}
