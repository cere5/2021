using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    public Rigidbody playerRigidbody; // 작성할 부분
    public float speed = 8f; // 작성할 부분

    void Start()
    {
        
    }


    void Update()
    {
        if(Input.GetKey(KeyCode.UpArrow) == true) // 작성할부분
        {
            playerRigidbody.AddForce(0f, 0f, speed);
        }
        if (Input.GetKey(KeyCode.DownArrow) == true)
        {
            playerRigidbody.AddForce(0f, 0f, -speed);
        }
        if (Input.GetKey(KeyCode.RightArrow) == true)
        {
            playerRigidbody.AddForce(speed, 0f, 0f);
        }
        if (Input.GetKey(KeyCode.LeftArrow) == true)
        {
            playerRigidbody.AddForce(-speed, 0f, 0f); 
        }
    }

    public void Die() // 작성할 부분
    {
        gameObject.SetActive(false);
    }
}
